% 5/4/2008 
% Used for generating the tables in the final version of the IEEE Comm.
% Letters article
% Format matlab output for latex table



rand_errors = 1;
mex_true = 1;
max_iterations = 60;
channel_adaptive = 0;

for n=8:2:8
for channel_index = 1:1:1

if channel_index == 1
    channel_type = 'BEC'
elseif channel_index == 2
    channel_type = 'BSC'
elseif channel_index == 3
    channel_type = 'PSK'
else
    disp('Error in channel index');
end

for RM_code = 0:0

load_filename = sprintf('%s_%d_%d_%d_%d_%d_mex', channel_type,n,RM_code,rand_errors,max_iterations,channel_adaptive);
out_file = sprintf('latex_table_%s_%d_%d_%d_%d_%d_mex.txt', channel_type,n,RM_code,rand_errors,max_iterations,channel_adaptive);
load([load_filename '.mat']);

fid = fopen(out_file, 'wt');
fprintf(fid,'\\begin{table*}[hbt]\n');
fprintf(fid,'\\begin{center}\n');
if RM_code == 1
fprintf(fid,'\\caption{$N=%d$, %s, RM code, BP decoder, Max iterations = %d, No frames = %d.}\n',2^n,channel_type,max_iterations,max_no_frames);
else
fprintf(fid,'\\caption{$N=%d$, %s, Polar code, BP decoder, Max iterations = %d, No frames = %d.}\n',2^n,channel_type,max_iterations,max_no_frames);
end
fprintf(fid,'\\label{tab:%s}\n',channel_type);
fprintf(fid,'\\begin{tabular}{');
fprintf(fid,'|c|');
for i=1:length(prmt)
fprintf(fid,'|c');
end
fprintf(fid,'|}\\hline\n');
if channel_type == 'BEC'
    fprintf(fid,'& \\multicolumn{%d}{c|}{Erasure probability $\\epsilon$}\\\\\\hline\n',length(prmt));
elseif channel_type == 'BSC'
    fprintf(fid,'& \\multicolumn{%d}{c|}{Error probability $\\epsilon$}\\\\\\hline\n',length(prmt));
elseif channel_type == 'PSK'
    fprintf(fid,'& \\multicolumn{%d}{c|}{Signal-to-noise ratio (dB)}\\\\\\hline\n',length(prmt));
end
%fprintf(fid,'$\\epsilon$ ');
fprintf(fid,'Rate ');
for i=1:1:length(prmt)
fprintf(fid,'& %3.2f ',prmt(i));
end
fprintf(fid,'\\\\\\hline\\hline\n');
for m=1:length(rate)
    fprintf(fid,'$%3.2f$ ',rate(m));
        for i=1:1:length(prmt)
            if ber_total(m,i) < 2
                fprintf(fid,' &  %6.5f ',ber_total(m,i));
            else
                fprintf(fid,' &  - ');
            end
        end
    fprintf(fid,'\\\\\\hline\n');
end
fprintf(fid,'\\end{tabular}\n');
fprintf(fid,'\\end{center}\n');
fprintf(fid,'\\end{table*}\n');


fclose(fid)
end % RM_code

end % channel type

end %n