#include "matrix.h"
#include "math.h"

void rvsl(mxArray *pR,mxArray *pOut)
{ 
  int N = mxGetNumberOfElements(pR);
  int i, j = 0;
  mxArray *odds, *evens;
  mxArray *oddsoutput, *evensoutput;
  double *ppR, *ppO, *pOddsIn, *pEvensIn, *pOddsOut, *pEvensOut;

  //mexPrintf("%d\n", N);
  ppR = mxGetPr(pR);
  ppO = mxGetPr(pOut);

  //  mexPrintf("PPR Value: %f\n", (*ppR));
  //  mexPrintf("PPO Value: %f\n", (*ppO));

  if ( N == 2){
    pOut = pR; //end of recursion
    *ppO = *ppR;
    *(ppO + 1) = *(ppR + 1);
    // mexPrintf("PPO Value: %f\n", (*ppO));
  }
  else
    {    
      // create a new array with odd and even indices 
      odds = mxCreateDoubleMatrix(N/2,1, mxREAL);
      evens = mxCreateDoubleMatrix(N/2,1, mxREAL);

      pOddsIn = mxGetPr(odds);
      pEvensIn = mxGetPr(evens);
    
      // populate the arrays
      for(i = 0; i < N; ){
	*(pOddsIn+j) = *(ppR + i++);
	*(pEvensIn+j) = *(ppR + i++);
	j++;
      }

      oddsoutput = mxCreateDoubleMatrix(N/2, 1, mxREAL);
      evensoutput = mxCreateDoubleMatrix(N/2, 1, mxREAL);
      pOddsOut = mxGetPr(oddsoutput);
      pEvensOut = mxGetPr(evensoutput);

      rvsl( odds, oddsoutput);
      rvsl( evens, evensoutput);

      for(j=0; j < N/2; j++){
	ppO[j] = pOddsOut[j];
      }

      for(j=0; j < N/2; j++){
	ppO[j+N/2] = pEvensOut[j];
      }
    } 
}


void mexFunction(int output_size, mxArray *output[], int input_size, const mxArray *input[])
{
  
  /* extract values and size from the matlab object */
  double*   pR = mxGetPr( input[0] );  /* values */
  int N = mxGetNumberOfElements( input[0] );
  output[0] = mxCreateDoubleMatrix(N,1, mxREAL);

  rvsl(input[0], output[0]);
   
 }
