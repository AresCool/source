% This file is used to generate the tables in the IEEE Comm Letters article
% 4 April 2008
% This version uses mex files
% 29 December 2007
% RM code
% This version has no bit reversal in encoding
% Uses submatrices of G_RM(n,n) in natural index order
clear all;
clc;

% Set simulation parameters
blksize = 8:2:8; % block size is 2^blksize
rand_errors = 1; % 0 for fixed no of erasures, 1 for variable no of erasures
rate_options = 0; % 0 for RM rates (tries all), 1 for user-specified rates
user_specified_rates = 0.09:0.1:0.89;
send_all_ones = 0;
channel_adaptive = 0; % set to 0 if erasure probability 1/2 is to be used for all calculations
max_iterations = 60;
max_no_frames = 1000; 
ferrlim = 1000;
run_quite = 1;
%channel_type = 'BEC';
BigNumber = 1000000;

time_start = cputime;

for channel_index = 1:1:1

if channel_index == 1
    channel_type = 'BEC'
elseif channel_index == 2
    channel_type = 'BSC'
elseif channel_index == 3
    channel_type = 'PSK'
else
    disp('Error in channel index');
end


switch lower(channel_type)
   case 'bec'
      prmt = 0.1:0.1:0.9;
   case {'bsc'}
      prmt = 0.05:0.05:0.45;
      %prmt = 0.35:0.01:0.40;
   case 'psk'
      prmt = -10:2:10 % SNR dB ( 1D modulation)
   case 'hdd'   % same as PSK but channel output with hard decisions
      prmt = 3:1:5 % SNR dB ( 1D modulation)
    otherwise
      disp('Specify channel type');
end

% set/save state of random no gen
rand('state',0); % set state to 0
randn('state',0); % set state to 0
%rand('state', sum(100*clock));
save_state = rand('state');
save_staten = randn('state');

fprintf('\n\n********** Beginning test of Polar RM Code ***********\n');



for rm=0:1:0
RM_code = rm; % set 1 if Reed-Muller selection rule is desired (decoding is always by belief prop)

% set/save state of random no gen
rand('state',0); % set state to 0
randn('state',0); % set state to 0
%rand('state', sum(100*clock));
save_state = rand('state');
save_staten = randn('state');


fprintf('********** RM_Code Type %d ***********\n',rm);
tic

for nn = 1:length(blksize)
    n = blksize(nn);


% save code parameters
save_filename = sprintf('%s_%d_%d_%d_%d_%d_mex', channel_type,n,RM_code,rand_errors,max_iterations,channel_adaptive);

N=2^n; % block length


rate = [];
switch rate_options
   case {0}  % RM rate
    for m=1:n-1
        K(m)= 1;
    for i=1:m
     K(m) = K(m)+nchoosek(n,i);
    end
        rate(m) = K(m)/N;
    end
   case 1  % linear rates
      rate = user_specified_rates;
   otherwise
      disp('Specify rate option');
end


if RM_code == 1
        %% For RM codes we need to find the number of 1s in the binary expansion of
        %% indices and pick the ones with the largest number of 1s.
        %% Need to be careful about bit-reversal
        w = zeros(N,1); % binary weights of indices
        for i=1:N
            a = dec2bin(i-1,n);
            ir = 1+ bin2dec(a(end:-1:1)); % bit reversed index
            %ir = i;
            w(ir) = 0;
            for j=1:n
                if a(j) == '1'
                    w(ir) = w(ir)+1;
                end
            end
        end
        [Vals, Inds] = sort(w,'ascend');
      else  % polarization coding
            %eff_eps = 1-caps(neps);
            %[L,I] = get_bec_erasure_rates(n,eff_eps);
            % fixed method for choosing frozen coordinates
            [Vals,Inds] = get_bec_erasure_rates(n,0.5);
      end;

ber_total = [];
fer_total = [];

for neps = 1:length(prmt)
% 
if channel_type == 'BSC'
    caps(neps) = 1+prmt(neps)*log2(prmt(neps))+(1-prmt(neps))*log2(1-prmt(neps));
elseif channel_type == 'BEC'
    caps(neps) = 1 - prmt(neps);
elseif channel_type == 'PSK' | 'HDD'
    snr = 10^(prmt(neps)/10);      % convert Eb/N0 from unit db to normal numbers
    sigma = (1/sqrt(snr)); 	% standard deviation of AWGN noise
    HY = quad(@(y) mut_inf(y,sigma^2),-20*sigma,20*sigma)/log(2);
    HN = log2(sqrt(2*pi*exp(1))*sigma);
    caps(neps) = HY - HN;
end

if (channel_adaptive == 1) & (RM_code == 0)
    eff_eps = 1-caps(neps);
    [Vals,Inds] = get_bec_erasure_rates(n,eff_eps);
end

ber =[];
fer =[];


for m=1:length(rate)
    K(m) = round(rate(m)*N);
    errs(m) = 0;
    nferr(m) = 0;
    nframe=0;
    cum_iter(m) = 0;

    if rate(m) < caps(neps);      % rate less than capacity
    frozen_positions = Inds(1:N-K(m));
    free_positions = sort(Inds(N-K(m)+1:N),'ascend');

    while nferr(m) <ferrlim & nframe < max_no_frames
        nframe = nframe + 1; 
        if send_all_ones == 0
            data_in=randsrc(K(m),1,[0 1]); % random data sequence
        else
            data_in = ones(K(m),1);
        end
        u = zeros(N,1);
        u(free_positions) = data_in; % set frozen positions to zero
        x = encode(u);
        if channel_type == 'BSC'
            e = zeros(N,1);
            if rand_errors == 1
                e = randsrc(N,1,[0 1; 1-prmt(neps) prmt(neps)]); 
            else
                e = randerr(N,1,floor(N*prmt(neps))); % fixed no of erasures
            end;
            y = mod(x+e,2);
            R = ones(N,n+1);
            L = ones(N,n+1);
            R(frozen_positions,1) = BigNumber;
            L(:,n+1) = y*prmt(neps)/(1-prmt(neps)) + (1-y)*(1-prmt(neps))/prmt(neps);
        elseif channel_type == 'BEC'
            e = zeros(N,1);
            if rand_errors == 1
                e = randsrc(N,1,[0 1; 1-prmt(neps) prmt(neps)]); 
            else
                e = randerr(N,1,floor(N*prmt(neps))); % fixed no of erasures
            end;
            R = ones(N,n+1);
            L = ones(N,n+1);
            R(frozen_positions,1) = BigNumber;
            L(:,n+1) = (1-x)*BigNumber+x*(1/BigNumber);
            L(find(e == 1),n+1) = 1;
        elseif channel_type == 'PSK' | 'HDD'   
            snr = 10^(prmt(neps)/10);      % convert Eb/N0 from unit db to normal numbers
            sigma = 1/sqrt(snr); 	% standard deviation of AWGN noise
            y=(2*x-1) + sigma*randn(N,1); % BPSK modulation and AWGN transmission 
            R = ones(N,n+1);
            L = ones(N,n+1);
            R(frozen_positions,1) = BigNumber;
            if channel_type == 'PSK'
                L(:,n+1) = exp(-2*y/sigma^2); % channel likelihoods
            elseif channel_type == 'HDD'
                efferr = 0.5*erfc(1/(sqrt(2)*sigma));
                L(find(y > 0),n+1) = efferr/(1-efferr);
                L(find(y <= 0),n+1) = (1-efferr)/efferr;
            end
            end
        % reduce the decoding problem
        R(:,1) = rvsl2(R(:,1));
        L(:,n+1) = rvsl2(L(:,n+1));
        
        err = 1;          
        iter = 0;
        while (iter < max_iterations) & (err > 0) 
            iter = iter +1;
        for k=1:n
            [C D] = fbp2(shffl2(R(:,k)),L(:,k+1));
            L(:,k) = rshffl2(D);
            R(:,k+1) = C;
        end
            v = zeros(N,1);  % output
            v(find(L(:,1).*R(:,1)<1)) = 1;
            v = rvsl2(v);
            data_out = v(free_positions);
            err= length(find(data_out~=data_in));
        end

        if run_quite == 0
            if err > 0
                display('Decoding failure!');
            else
                fprintf(1,'Decoding successfully finished at iteration no %d\n',iter-1);
            end
        end

           if err>0
              nferr(m) = nferr(m)+1;
           end   
           errs(m) = errs(m) + err;
           cum_iter(m) = cum_iter(m) + iter;

           if rem(nframe,3)==0 | nferr(m)==ferrlim
              ber(m) = errs(m)/nframe/length(data_in);
              fer(m) = nferr(m)/nframe;
              aveg_iter(m) = cum_iter(m)/nframe;

              if run_quite == 0

              fprintf('************** %s Error Rate = %5.2f db **************\n',channel_type, prmt(neps));
              fprintf('Frame size = %d, rate %5.2f, capacity %5.2f\n', length(data_in), R, ...
                  caps(neps));
              fprintf('%d frames transmitted, %d frames in error.\n', nframe, nferr(m));
              fprintf('Bit Error Rate ');
              fprintf('%8.4e    ', ber(m));
              fprintf('Frame Error Rate ');
              fprintf('%8.4e     ', fer(m));
              fprintf('Average iterations ');
              fprintf('%8.1f    \n', aveg_iter(m));
              end  
            end

    end  % while
  ber(m) = errs(m)/nframe/length(data_in);
  fer(m) = nferr(m)/nframe;
else
    ber(m) = 2;
    fer(m) = 2;
    end

end  % m  % rate loop
fprintf('********** Finished n = %d, prmt = %4.2f ***********    ',n,prmt(neps));
toc

ber_total = [ber_total  ber'];
fer_total = [fer_total  fer'];
    
end;  % neps  channel parameter loop

fprintf('********** Saving results in %s ***********\n', [save_filename '.mat']);
save([save_filename '.mat']);


end
end
end

total_time = cputime-time_start;
fprintf('Total time %5.3f\n',total_time);

