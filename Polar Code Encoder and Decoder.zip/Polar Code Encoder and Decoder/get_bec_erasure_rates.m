% 27.12.2007
% compute the erasure probabilities

function [L,I] = get_bec_erasure_rates(n,eps);

N= 2^n; % no of channels
e = eps;
for i=1:n
e1 = 2*e - e.*e;
e2 = e.*e;
e =[e1; e2];
end

[L I] = sort(e,'descend');

% save_fn = sprintf('bec_order_%d', n);
% save([save_fn '.mat'],'I');

% figure(1);
% bar(e);
% figure(2);
% bar(sort(e,'descend'));