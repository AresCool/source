% shuffle function
function x = shffl(y);

N = size(y,1);
x= reshape(reshape(y,2,N/2)',N,1);
        
    
