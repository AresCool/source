% inverse of the shffl function
function x = rshffl(y);

N = size(y,1);
x=y;
x=  reshape(reshape(x,N/2,2)',N,1);
        