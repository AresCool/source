
function [ RR LL] = fbp(R,L)

N = size(R,1);

for i=1:N/2
RR(i,1)     = (1+ R(i)*R(i+N/2)*L(i+N/2))/(R(i)+R(i+N/2)*L(i+N/2));
RR(i+N/2,1) = R(i+N/2)*(1+R(i)*L(i))/(R(i)+L(i));
LL(i,1)     = (1+ L(i)*L(i+N/2)*R(i+N/2))/(L(i)+L(i+N/2)*R(i+N/2));
LL(i+N/2,1) = L(i+N/2)*(1+L(i)*R(i))/(L(i)+R(i));
end
