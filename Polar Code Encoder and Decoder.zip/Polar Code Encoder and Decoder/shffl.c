#include "matrix.h"
#include "math.h"

void mexFunction(int output_size, mxArray *output[], int input_size, const mxArray *input[])
{
  
  /* extract values and size from the matlab object */
  double*   pIn = mxGetPr( input[0] );  /* values */
  int N = mxGetNumberOfElements( input[0] );
  int i,j,N2;
  double *pOut;

  N2 = N/2;

  j = 0;

  output[0] = mxCreateDoubleMatrix(N,1, mxREAL);
  pOut = mxGetPr(output[0]);
  
  // i : source 

  // j : destination for even indices

  // j + N2 : destination for odd indices

  for ( i = 0; i < N; i++ ){
    *(pOut + j) = *(pIn + i++);
    *(pOut + j + N2) = *(pIn + i);
    j++;
  }
}
