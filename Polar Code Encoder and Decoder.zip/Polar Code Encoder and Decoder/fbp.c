#include "matrix.h"
#include "math.h"

void mexFunction(int output_size, mxArray *output[], int input_size, const mxArray *input[])
{
  
  /* extract values and size from the matlab object */
  double*   pR = mxGetPr( input[0] );  /* values */
  double*   pL = mxGetPr( input[1] );  /* values */
  int iLengthR = mxGetNumberOfElements( input[0] );
  int N = iLengthR;
  int N2 = N/2;
  int i,iN2;
  double *pRR, *pLL;  
    
  output[0] = mxCreateDoubleMatrix(N,1, mxREAL);
  output[1] = mxCreateDoubleMatrix(N,1, mxREAL);
   
   pRR = mxGetPr(output[0]);
   pLL = mxGetPr(output[1]);
   
   for ( i = 0; i < N/2; i++ ){
     iN2 = i + N/2; /* #define iN2 (i + N/2) */
     *(pRR+i) = (1 + (*(pR+i))*(*(pR+iN2))*(*(pL+iN2))) / ((*(pR+i)) + (*(pR+iN2))*(*(pL+iN2)));
     *(pRR+iN2) = (*(pR+iN2)*(1+(*(pR+i))*(*(pL+i))))/ ((*(pR+i)+(*(pL+i))));
     *(pLL+i) = (1 + (*(pL+i))*(*(pL+iN2))*(*(pR+iN2))) / ((*(pL+i)) + (*(pL+iN2))*(*(pR+iN2)));
     *(pLL+iN2) = (*(pL+iN2))*(1 + (*(pL+i))*(*(pR+i))) / ((*(pL+i)) + (*(pR+i)));
   }
}
